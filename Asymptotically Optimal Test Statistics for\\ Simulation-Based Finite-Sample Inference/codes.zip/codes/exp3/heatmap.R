## ============================================================================
## CREATE FIGURE-6-STYLE HEATMAPS FROM SAVED CSV RESULTS
##
## Reads:
##   ~/R_Simuls/exp3_objectiveperturb/
##       n_<n>_eps_<epsilon>_eff/summary/Repro_logistic.csv
##
## Configurations:
##   n       = 100, 200, 500, 1000
##   epsilon = 0.1, 0.3, 1, 3
##
## Outputs:
##   heatmap_coverage.pdf
##   heatmap_width.pdf
##   heatmap_coverage.png
##   heatmap_width.png
##   heatmap_data.csv
## ============================================================================


## ============================================================================
## 1. PATH
## ============================================================================

ROOT_DIR <- path.expand(
  "~/R_Simuls/exp3_objectiveperturb/eff"
)

setwd(ROOT_DIR)


## ============================================================================
## 2. CONFIGURATIONS
## ============================================================================

n_values <- c(
  100,
  200,
  500,
  1000
)

eps_values <- c(
  0.1,
  0.3,
  1,
  3
)


## ============================================================================
## 3. FUNCTION TO FORMAT EPSILON EXACTLY AS USED IN FOLDER NAMES
## ============================================================================

format_eps <- function(eps) {
  
  if (eps == 0.1) return("0.1")
  if (eps == 0.3) return("0.3")
  if (eps == 1.0) return("1")
  if (eps == 3.0) return("3")
  
  format(
    eps,
    scientific = FALSE,
    trim = TRUE
  )
}


## ============================================================================
## 4. READ ALL 16 SUMMARY CSV FILES
## ============================================================================

results <- data.frame(
  n = integer(0),
  epsilon = numeric(0),
  coverage = numeric(0),
  width_all = numeric(0),
  width_real = numeric(0),
  n_full_range = integer(0),
  n_no_accepted_point = integer(0),
  mean_seconds = numeric(0)
)


for (n_cur in n_values) {
  
  for (eps_cur in eps_values) {
    
    eps_string <- format_eps(
      eps_cur
    )
    
    folder_name <- sprintf(
      "n_%d_eps_%s_eff",
      n_cur,
      eps_string
    )
    
    csv_file <- file.path(
      ROOT_DIR,
      folder_name,
      "summary",
      "Repro_logistic.csv"
    )
    
    
    cat(
      sprintf(
        "Reading: %s\n",
        csv_file
      )
    )
    
    
    if (!file.exists(csv_file)) {
      
      warning(
        sprintf(
          "FILE NOT FOUND: %s",
          csv_file
        )
      )
      
      next
    }
    
    
    tmp <- read.csv(
      csv_file,
      header = TRUE
    )
    
    
    ## ------------------------------------------------------------
    ## Check required columns
    ## ------------------------------------------------------------
    
    required_columns <- c(
      "coverage",
      "width_all",
      "width_real",
      "n_full_range",
      "n_no_accepted_point",
      "mean_seconds"
    )
    
    
    missing_columns <- setdiff(
      required_columns,
      colnames(tmp)
    )
    
    
    if (length(missing_columns) > 0L) {
      
      stop(
        sprintf(
          paste0(
            "\nMissing column(s) in:\n%s\n\n",
            "Missing: %s"
          ),
          csv_file,
          paste(
            missing_columns,
            collapse = ", "
          )
        )
      )
    }
    
    
    ## ------------------------------------------------------------
    ## Store result
    ## ------------------------------------------------------------
    
    results <- rbind(
      results,
      data.frame(
        n = n_cur,
        epsilon = eps_cur,
        coverage = tmp$coverage[1],
        width_all = tmp$width_all[1],
        width_real = tmp$width_real[1],
        n_full_range = tmp$n_full_range[1],
        n_no_accepted_point =
          tmp$n_no_accepted_point[1],
        mean_seconds =
          tmp$mean_seconds[1]
      )
    )
  }
}


## ============================================================================
## 5. CHECK RESULTS
## ============================================================================

cat("\n")
cat("============================================================\n")
cat("RESULTS READ FROM CSV FILES\n")
cat("============================================================\n")

print(
  results,
  row.names = FALSE
)

cat("============================================================\n\n")


if (nrow(results) != 16L) {
  
  warning(
    sprintf(
      "Expected 16 configurations but found %d.",
      nrow(results)
    )
  )
}


## Save combined data used for plotting

write.csv(
  results,
  file.path(
    ROOT_DIR,
    "heatmap_data.csv"
  ),
  row.names = FALSE
)


## ============================================================================
## 6. CREATE MATRICES
##
## Rows    = epsilon
## Columns = n
## ============================================================================

coverage_matrix <- matrix(
  NA_real_,
  nrow = length(eps_values),
  ncol = length(n_values),
  dimnames = list(
    paste0(
      "\u03b5 = ",
      eps_values
    ),
    n_values
  )
)


width_matrix <- coverage_matrix

width_real_matrix <- coverage_matrix

fallback_matrix <- coverage_matrix


for (i in seq_along(eps_values)) {
  
  for (j in seq_along(n_values)) {
    
    row_match <- which(
      results$n == n_values[j] &
        abs(
          results$epsilon -
            eps_values[i]
        ) < 1e-12
    )
    
    
    if (length(row_match) == 1L) {
      
      coverage_matrix[i, j] <-
        results$coverage[row_match]
      
      width_matrix[i, j] <-
        results$width_all[row_match]
      
      width_real_matrix[i, j] <-
        results$width_real[row_match]
      
      fallback_matrix[i, j] <-
        results$n_full_range[row_match]
    }
  }
}


## ============================================================================
## 7. PRINT MATRICES
## ============================================================================

cat("\nCOVERAGE MATRIX\n")
print(
  round(
    coverage_matrix,
    3
  )
)

cat("\nWIDTH MATRIX -- ALL INTERVALS\n")
print(
  round(
    width_matrix,
    2
  )
)

cat("\nWIDTH MATRIX -- REAL INTERVALS ONLY\n")
print(
  round(
    width_real_matrix,
    2
  )
)

cat("\nFULL-RANGE FALLBACK MATRIX\n")
print(
  fallback_matrix
)


## ============================================================================
## 8. HEATMAP FUNCTION
##
## Similar layout to Figure 6:
##
##   epsilon on vertical axis
##   sample size n on horizontal axis
##   numerical value inside every cell
## ============================================================================

draw_heatmap <- function(
    Z,
    main_title,
    legend_title,
    digits = 2,
    palette_function
) {
  
  nr <- nrow(Z)
  nc <- ncol(Z)
  
  
  ## Reverse rows so epsilon=0.1 appears at top,
  ## matching the orientation of Figure 6.
  
  Z_plot <- Z[
    nr:1,
    ,
    drop = FALSE
  ]
  
  
  image(
    x = seq_len(nc),
    y = seq_len(nr),
    z = t(Z_plot),
    col = palette_function(100),
    axes = FALSE,
    xlab = "Number of Samples (N)",
    ylab = expression(
      paste(
        "Privacy Parameter (",
        epsilon,
        ")"
      )
    ),
    main = main_title
  )
  
  
  axis(
    side = 1,
    at = seq_len(nc),
    labels = n_values
  )
  
  
  axis(
    side = 2,
    at = seq_len(nr),
    labels = rev(
      eps_values
    ),
    las = 1
  )
  
  
  ## Cell labels
  
  for (i in seq_len(nr)) {
    
    for (j in seq_len(nc)) {
      
      original_i <- nr - i + 1L
      
      value <- Z[
        original_i,
        j
      ]
      
      
      if (is.finite(value)) {
        
        label <- formatC(
          value,
          format = "f",
          digits = digits
        )
        
        
        text(
          x = j,
          y = i,
          labels = label,
          cex = 1.15
        )
      }
    }
  }
  
  
  box()
  
  
  ## ------------------------------------------------------------
  ## Simple color legend
  ## ------------------------------------------------------------
  
  usr <- par(
    "usr"
  )
  
  x_left <- usr[2] + 0.15
  x_right <- usr[2] + 0.30
  
  y_seq <- seq(
    usr[3],
    usr[4],
    length.out = 101
  )
  
  z_range <- range(
    Z,
    finite = TRUE
  )
  
  cols <- palette_function(
    100
  )
  
  
  for (k in 1:100) {
    
    rect(
      xleft = x_left,
      ybottom = y_seq[k],
      xright = x_right,
      ytop = y_seq[k + 1L],
      col = cols[k],
      border = NA,
      xpd = TRUE
    )
  }
  
  
  axis(
    side = 4,
    at = seq(
      usr[3],
      usr[4],
      length.out = 5
    ),
    labels = formatC(
      seq(
        z_range[1],
        z_range[2],
        length.out = 5
      ),
      format = "f",
      digits = digits
    ),
    las = 1,
    line = -1,
    xpd = TRUE
  )
  
  
  mtext(
    legend_title,
    side = 4,
    line = 3.3,
    xpd = TRUE
  )
}


## ============================================================================
## 9. COLOR PALETTES
##
## Coverage:
##   low -> light
##   high -> dark
##
## Width:
##   low -> light
##   high -> dark
##
## Uses base R only.
## ============================================================================

coverage_palette <- function(n) {
  
  colorRampPalette(
    c(
      "#fff5f0",
      "#fcbba1",
      "#fb6a4a",
      "#cb181d",
      "#67000d"
    )
  )(n)
}


width_palette <- function(n) {
  
  colorRampPalette(
    c(
      "#fff5f0",
      "#fcbba1",
      "#fb6a4a",
      "#cb181d",
      "#67000d"
    )
  )(n)
}


## ============================================================================
## 10. COVERAGE HEATMAP -- PDF
## ============================================================================

pdf(
  file.path(
    ROOT_DIR,
    "heatmap_coverage.pdf"
  ),
  width = 7,
  height = 5.5
)

par(
  mar = c(
    5,
    5,
    4,
    7
  )
)

draw_heatmap(
  Z = coverage_matrix,
  main_title =
    "Coverage of 90% CI\nEfficient Operator II",
  legend_title =
    "Coverage Rate",
  digits = 3,
  palette_function =
    coverage_palette
)

dev.off()


## ============================================================================
## 11. COVERAGE HEATMAP -- PNG
## ============================================================================

png(
  file.path(
    ROOT_DIR,
    "heatmap_coverage.png"
  ),
  width = 1600,
  height = 1200,
  res = 200
)

par(
  mar = c(
    5,
    5,
    4,
    7
  )
)

draw_heatmap(
  Z = coverage_matrix,
  main_title =
    "Coverage of 90% CI\nEfficient Operator II",
  legend_title =
    "Coverage Rate",
  digits = 3,
  palette_function =
    coverage_palette
)

dev.off()


## ============================================================================
## 12. WIDTH HEATMAP -- PDF
##
## This uses width_all.
##
## Therefore full-range conservative fallback intervals are INCLUDED.
## ============================================================================

pdf(
  file.path(
    ROOT_DIR,
    "heatmap_width.pdf"
  ),
  width = 7,
  height = 5.5
)

par(
  mar = c(
    5,
    5,
    4,
    7
  )
)

draw_heatmap(
  Z = width_matrix,
  main_title =
    "Width of 90% CI\nEfficient Operator II",
  legend_title =
    "CI Width",
  digits = 2,
  palette_function =
    width_palette
)

dev.off()


## ============================================================================
## 13. WIDTH HEATMAP -- PNG
## ============================================================================

png(
  file.path(
    ROOT_DIR,
    "heatmap_width.png"
  ),
  width = 1600,
  height = 1200,
  res = 200
)

par(
  mar = c(
    5,
    5,
    4,
    7
  )
)

draw_heatmap(
  Z = width_matrix,
  main_title =
    "Width of 90% CI\nEfficient Operator II",
  legend_title =
    "CI Width",
  digits = 2,
  palette_function =
    width_palette
)

dev.off()


## ============================================================================
## 14. OPTIONAL: COVERAGE + WIDTH IN ONE FIGURE
## ============================================================================

pdf(
  file.path(
    ROOT_DIR,
    "figure6_operatorII.pdf"
  ),
  width = 12,
  height = 5.5
)

par(
  mfrow = c(
    1,
    2
  ),
  mar = c(
    5,
    5,
    4,
    6
  )
)


draw_heatmap(
  Z = coverage_matrix,
  main_title =
    "Coverage of 90% CI\n(Efficient Operator II)",
  legend_title =
    "Coverage Rate",
  digits = 3,
  palette_function =
    coverage_palette
)


draw_heatmap(
  Z = width_matrix,
  main_title =
    "Width of 90% CI\n(Efficient Operator II)",
  legend_title =
    "CI Width",
  digits = 2,
  palette_function =
    width_palette
)


dev.off()


## PNG combined figure

png(
  file.path(
    ROOT_DIR,
    "figure6_operatorII.png"
  ),
  width = 2400,
  height = 1000,
  res = 200
)

par(
  mfrow = c(
    1,
    2
  ),
  mar = c(
    5,
    5,
    4,
    6
  )
)


draw_heatmap(
  Z = coverage_matrix,
  main_title =
    "Coverage of 90% CI\n(Efficient Operator II)",
  legend_title =
    "Coverage Rate",
  digits = 3,
  palette_function =
    coverage_palette
)


draw_heatmap(
  Z = width_matrix,
  main_title =
    "Width of 90% CI\n(Efficient Operator II)",
  legend_title =
    "CI Width",
  digits = 2,
  palette_function =
    width_palette
)


dev.off()


## ============================================================================
## 15. FINISHED
## ============================================================================

cat("\n")
cat("============================================================\n")
cat("HEATMAPS CREATED SUCCESSFULLY\n")
cat("============================================================\n")

cat(
  sprintf(
    "Coverage PDF : %s\n",
    file.path(
      ROOT_DIR,
      "heatmap_coverage.pdf"
    )
  )
)

cat(
  sprintf(
    "Width PDF    : %s\n",
    file.path(
      ROOT_DIR,
      "heatmap_width.pdf"
    )
  )
)

cat(
  sprintf(
    "Combined PDF : %s\n",
    file.path(
      ROOT_DIR,
      "figure6_operatorII.pdf"
    )
  )
)

cat(
  sprintf(
    "Combined PNG : %s\n",
    file.path(
      ROOT_DIR,
      "figure6_operatorII.png"
    )
  )
)

cat(
  sprintf(
    "Plot data    : %s\n",
    file.path(
      ROOT_DIR,
      "heatmap_data.csv"
    )
  )
)

cat("============================================================\n")