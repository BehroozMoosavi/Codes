## ============================================================================
## LINEAR REGRESSION -- EFFICIENT METHOD POWER HEATMAP
##
## Reads existing CSV:
##   Efficient_INT.csv
##
## Rows    = beta1 true
## Columns = sample size n
##
## Does NOT rerun simulations.
## ============================================================================


## ============================================================================
## 1. PATHS
## ============================================================================

PROJECT_DIR <- path.expand(
  "~/R_Simuls/Linearegression"
)

RESULTS_DIR <- file.path(
  PROJECT_DIR,
  "results_eff"
)

CSV_FILE <- file.path(
  RESULTS_DIR,
  "Efficient_INT.csv"
)

OUTPUT_PNG <- file.path(
  RESULTS_DIR,
  "Efficient_power_heatmap.png"
)

OUTPUT_PDF <- file.path(
  RESULTS_DIR,
  "Efficient_power_heatmap.pdf"
)


## ============================================================================
## 2. READ CSV
## ============================================================================

if (!file.exists(CSV_FILE)) {
  stop(
    paste0(
      "CSV file not found:\n",
      CSV_FILE
    )
  )
}


power_df <- read.csv(
  CSV_FILE,
  row.names = 1,
  check.names = FALSE
)


cat("\nData read from:\n")
cat(CSV_FILE, "\n\n")

print(power_df)


## ============================================================================
## 3. CONVERT TO NUMERIC MATRIX
## ============================================================================

power_matrix <- as.matrix(
  power_df
)

storage.mode(
  power_matrix
) <- "numeric"


## sample sizes

n_values <- as.numeric(
  colnames(
    power_matrix
  )
)


## true beta1 values

beta_values <- as.numeric(
  rownames(
    power_matrix
  )
)


cat("\nSample sizes:\n")
print(n_values)

cat("\nTrue beta1 values:\n")
print(beta_values)

cat("\nPower matrix:\n")
print(power_matrix)


## ============================================================================
## 4. HEATMAP FUNCTION
## ============================================================================

draw_power_heatmap <- function(
    power_matrix,
    n_values,
    beta_values
) {
  
  nr <- nrow(
    power_matrix
  )
  
  nc <- ncol(
    power_matrix
  )
  
  
  ## Reverse rows so beta1 = 1 is at the top
  ## and beta1 = 0 is at the bottom.
  ##
  ## Remove rev() if you prefer 0 at the top.
  
  Z <- power_matrix[
    nr:1,
    ,
    drop = FALSE
  ]
  
  beta_plot <- rev(
    beta_values
  )
  
  
  ## --------------------------------------------------------------------------
  ## Colors
  ## --------------------------------------------------------------------------
  
  cols <- colorRampPalette(
    c(
      "#fff5f0",
      "#fee0d2",
      "#fcbba1",
      "#fc9272",
      "#fb6a4a",
      "#ef3b2c",
      "#cb181d",
      "#99000d"
    )
  )(100)
  
  
  ## --------------------------------------------------------------------------
  ## Main heatmap
  ## --------------------------------------------------------------------------
  
  image(
    x = seq_len(nc),
    y = seq_len(nr),
    z = t(Z),
    col = cols,
    zlim = c(0, 1),
    axes = FALSE,
    xlab = "Number of Samples (N)",
    ylab = expression(beta[1]),
    main = "Efficient Method",
    useRaster = TRUE
  )
  
  
  ## X axis
  
  axis(
    side = 1,
    at = seq_len(nc),
    labels = n_values,
    cex.axis = 1.1
  )
  
  
  ## Y axis
  
  axis(
    side = 2,
    at = seq_len(nr),
    labels = beta_plot,
    las = 1,
    cex.axis = 1.1
  )
  
  
  ## --------------------------------------------------------------------------
  ## Numerical values inside cells
  ## --------------------------------------------------------------------------
  
  for (i in seq_len(nr)) {
    
    for (j in seq_len(nc)) {
      
      value <- Z[
        i,
        j
      ]
      
      
      if (is.finite(value)) {
        
        label <- sprintf(
          "%.3f",
          value
        )
        
        
        ## White text for high-power dark cells,
        ## black text otherwise.
        
        text_col <- if (
          value >= 0.65
        ) {
          "white"
        } else {
          "black"
        }
        
        
        text(
          x = j,
          y = i,
          labels = label,
          cex = 1.05,
          font = 2,
          col = text_col
        )
      }
    }
  }
  
  
  box()
  
  
  ## ==========================================================================
  ## COLOR BAR
  ## ==========================================================================
  
  usr <- par(
    "usr"
  )
  
  
  xleft <- usr[2] + 0.25
  xright <- usr[2] + 0.45
  
  
  y_breaks <- seq(
    usr[3],
    usr[4],
    length.out = 101
  )
  
  
  for (k in seq_len(100)) {
    
    rect(
      xleft = xleft,
      ybottom = y_breaks[k],
      xright = xright,
      ytop = y_breaks[k + 1],
      col = cols[k],
      border = NA,
      xpd = TRUE
    )
  }
  
  
  ## Color-bar ticks
  
  power_ticks <- seq(
    0,
    1,
    by = 0.2
  )
  
  
  y_ticks <- usr[3] +
    power_ticks *
    (
      usr[4] -
        usr[3]
    )
  
  
  axis(
    side = 4,
    at = y_ticks,
    labels = sprintf(
      "%.1f",
      power_ticks
    ),
    las = 1,
    line = -1,
    xpd = TRUE
  )
  
  
  mtext(
    "Power",
    side = 4,
    line = 3.5,
    xpd = TRUE
  )
}


## ============================================================================
## 5. SAVE PNG
## ============================================================================

png(
  OUTPUT_PNG,
  width = 1700,
  height = 1200,
  res = 200
)

par(
  mar = c(
    5,
    5,
    4,
    8
  )
)


draw_power_heatmap(
  power_matrix,
  n_values,
  beta_values
)


dev.off()


## ============================================================================
## 6. SAVE PDF
## ============================================================================

pdf(
  OUTPUT_PDF,
  width = 8,
  height = 5.8
)

par(
  mar = c(
    5,
    5,
    4,
    8
  )
)


draw_power_heatmap(
  power_matrix,
  n_values,
  beta_values
)


dev.off()


## ============================================================================
## 7. FINISHED
## ============================================================================

cat("\n")
cat("============================================================\n")
cat("POWER HEATMAP CREATED\n")
cat("============================================================\n")

cat(
  sprintf(
    "Input CSV : %s\n",
    CSV_FILE
  )
)

cat(
  sprintf(
    "PNG       : %s\n",
    OUTPUT_PNG
  )
)

cat(
  sprintf(
    "PDF       : %s\n",
    OUTPUT_PDF
  )
)

cat("============================================================\n")