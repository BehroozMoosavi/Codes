## ============================================================================
## exp2_efficient_lr_CORRECTED.R
##
## Linear regression -- Efficient Repro method
##
## Corrections relative to the previous version:
##
##   1. SAME Efficient/GLS partialling-out statistic.
##   2. SAME independent auxiliary cloud.
##   3. MULTI-START nuisance optimization.
##   4. Numerical/statistical failures NEVER manufacture rejection.
##   5. Failed/unresolved replications are recorded separately.
##   6. For power calculation, unresolved cases are conservatively treated
##      as NON-REJECTION.
##   7. set.seed(rep_idx + 1000L).
##
## Parameter:
##   theta = (beta1, beta0, mu, tau, sa)
##
## H0:
##   beta1 = 0
##
## ============================================================================


## ============================================================================
## 0. DIRECTORIES
## ============================================================================

PROJECT_DIR <- path.expand(
  "~/R_Simuls/Linearegression"
)

dir.create(
  PROJECT_DIR,
  recursive = TRUE,
  showWarnings = FALSE
)

setwd(PROJECT_DIR)


RESULTS_DIR <- file.path(
  PROJECT_DIR,
  "results_eff_corrected"
)

dir.create(
  RESULTS_DIR,
  recursive = TRUE,
  showWarnings = FALSE
)


## ============================================================================
## 1. FIXED SETTINGS
## ============================================================================

mu_x   <- 0.5
tau_x  <- 1.0
beta0  <- -0.5
sa_eps <- 0.5

alpha <- 0.05

R_synthetic <- 200L
R_aux       <- 400L

h_fd <- 1e-3

delta <- 2.0
ep    <- 1.0

reps <- 1000L


## nuisance = (beta0, mu, tau, sa)

nuisance_start <- c(
  beta0,
  mu_x,
  tau_x,
  sa_eps
)

nuisance_lower <- c(
  -5.0,
  -5.0,
  0.001,
  0.001
)

nuisance_upper <- c(
  5.0,
  5.0,
  5.0,
  5.0
)


rank_threshold <-
  floor(
    alpha *
      (R_synthetic + 1L)
  ) + 1L


cat(
  sprintf(
    "R = %d\n",
    R_synthetic
  )
)

cat(
  sprintf(
    "R_aux = %d\n",
    R_aux
  )
)

cat(
  sprintf(
    "alpha = %.3f\n",
    alpha
  )
)

cat(
  sprintf(
    "rank threshold = %d\n\n",
    rank_threshold
  )
)


## ============================================================================
## 2. PACKAGES / PARALLEL
## ============================================================================

list.of.packages <- c(
  "foreach",
  "doSNOW",
  "parallelly"
)

new.packages <-
  list.of.packages[
    !(list.of.packages %in%
        installed.packages()[, "Package"])
  ]


if (length(new.packages) > 0L) {
  
  install.packages(
    new.packages,
    dependencies = TRUE
  )
}


for (package.i in list.of.packages) {
  
  suppressPackageStartupMessages(
    library(
      package.i,
      character.only = TRUE
    )
  )
}


## Avoid nested BLAS threading

Sys.setenv(
  OMP_NUM_THREADS = "1",
  OPENBLAS_NUM_THREADS = "1",
  MKL_NUM_THREADS = "1",
  VECLIB_MAXIMUM_THREADS = "1",
  NUMEXPR_NUM_THREADS = "1"
)


n.cores <- 124L

cl <- parallel::makePSOCKcluster(
  n.cores
)

doSNOW::registerDoSNOW(
  cl
)


## ============================================================================
## 3. BASIC UTILITIES
## ============================================================================

clamp_val <- function(x, a, b) {
  
  pmin(
    pmax(
      x,
      a
    ),
    b
  )
}


clamp_nuisance <- function(x) {
  
  pmin(
    pmax(
      x,
      nuisance_lower
    ),
    nuisance_upper
  )
}


## ============================================================================
## 4. DP SUMMARY MECHANISM
##
## Identical DGP/summary structure to previous code.
## ============================================================================

sdp_vec_lr <- function(
    ux,
    uy,
    noise,
    delta,
    theta,
    ep,
    n
) {
  
  beta1  <- theta[1]
  beta0_ <- theta[2]
  mu     <- theta[3]
  tau    <- theta[4]
  sa     <- theta[5]
  
  
  x <- ux * tau + mu
  
  y <-
    beta0_ +
    beta1 * x +
    uy * sa
  
  
  xc <- clamp_val(
    x,
    -delta,
    delta
  )
  
  
  yc <- clamp_val(
    y,
    -delta,
    delta
  )
  
  
  xyc <- clamp_val(
    x * y,
    -delta^2,
    delta^2
  )
  
  
  ep_split <- ep / sqrt(5)
  
  
  xbar <-
    rowMeans(xc) +
    (2 * delta /
       (n * ep_split)) *
    noise[, 1]
  
  
  ybar <-
    rowMeans(yc) +
    (2 * delta /
       (n * ep_split)) *
    noise[, 2]
  
  
  x2bar <-
    rowMeans(xc^2) +
    (delta^2 /
       (n * ep_split)) *
    noise[, 3]
  
  
  y2bar <-
    rowMeans(yc^2) +
    (delta^2 /
       (n * ep_split)) *
    noise[, 4]
  
  
  xybar <-
    rowMeans(xyc) +
    (2 * delta^2 /
       (n * ep_split)) *
    noise[, 5]
  
  
  cbind(
    xbar,
    ybar,
    x2bar,
    y2bar,
    xybar
  )
}


## ============================================================================
## 5. SAFE EIGENVALUE-FLOORED INVERSE
##
## Kept exactly in the Efficient convention you used.
## ============================================================================

safe_inv_general <- function(
    A,
    ridge = 1e-8
) {
  
  if (
    any(!is.finite(A))
  ) {
    stop(
      "Non-finite matrix in safe_inv_general()."
    )
  }
  
  
  A_sym <-
    0.5 *
    (
      A +
        t(A)
    )
  
  
  eg <- eigen(
    A_sym,
    symmetric = TRUE
  )
  
  
  if (
    any(!is.finite(eg$values)) ||
    any(!is.finite(eg$vectors))
  ) {
    stop(
      "Non-finite eigendecomposition."
    )
  }
  
  
  eigvals_floored <-
    pmax(
      eg$values,
      ridge
    )
  
  
  eg$vectors %*%
    diag(
      1 / eigvals_floored,
      nrow = length(
        eigvals_floored
      )
    ) %*%
    t(
      eg$vectors
    )
}


## ============================================================================
## 6. EFFICIENT DIRECTION
##
## C(theta)
##
## SAME GLS partialling-out construction:
##
##   C =
##   Sigma^{-1}
##   [
##      d_beta -
##      D_eta
##      (D_eta' Sigma^{-1} D_eta)^{-1}
##      D_eta' Sigma^{-1} d_beta
##   ]
##
## Auxiliary cloud ONLY.
## ============================================================================

efficient_direction_lr <- function(
    theta,
    aux_ux,
    aux_uy,
    aux_N,
    delta,
    ep,
    n,
    cache
) {
  
  ## --------------------------------------------------------------------------
  ## Cache
  ## --------------------------------------------------------------------------
  
  key <- paste(
    sprintf(
      "%.10g",
      theta
    ),
    collapse = "_"
  )
  
  
  if (
    exists(
      key,
      envir = cache,
      inherits = FALSE
    )
  ) {
    
    return(
      get(
        key,
        envir = cache,
        inherits = FALSE
      )
    )
  }
  
  
  h <- h_fd
  
  
  beta1  <- theta[1]
  beta0_ <- theta[2]
  mu     <- theta[3]
  tau    <- theta[4]
  sa     <- theta[5]
  
  
  ## Parameter-domain check
  
  if (
    !is.finite(tau) ||
    !is.finite(sa) ||
    tau <= 0 ||
    sa <= 0
  ) {
    
    direction <- rep(
      NA_real_,
      5
    )
    
    assign(
      key,
      direction,
      envir = cache
    )
    
    return(direction)
  }
  
  
  ## --------------------------------------------------------------------------
  ## Center auxiliary cloud
  ## --------------------------------------------------------------------------
  
  x_center <-
    aux_ux *
    tau +
    mu
  
  
  xc_center <- clamp_val(
    x_center,
    -delta,
    delta
  )
  
  
  xc2_center <-
    xc_center^2
  
  
  ep_split <-
    ep /
    sqrt(5)
  
  
  y_center <-
    beta0_ +
    beta1 *
    x_center +
    aux_uy *
    sa
  
  
  yc_center <- clamp_val(
    y_center,
    -delta,
    delta
  )
  
  
  xyc_center <- clamp_val(
    x_center *
      y_center,
    -delta^2,
    delta^2
  )
  
  
  xbar_c <-
    rowMeans(
      xc_center
    ) +
    (
      2 *
        delta /
        (
          n *
            ep_split
        )
    ) *
    aux_N[, 1]
  
  
  ybar_c <-
    rowMeans(
      yc_center
    ) +
    (
      2 *
        delta /
        (
          n *
            ep_split
        )
    ) *
    aux_N[, 2]
  
  
  x2bar_c <-
    rowMeans(
      xc2_center
    ) +
    (
      delta^2 /
        (
          n *
            ep_split
        )
    ) *
    aux_N[, 3]
  
  
  y2bar_c <-
    rowMeans(
      yc_center^2
    ) +
    (
      delta^2 /
        (
          n *
            ep_split
        )
    ) *
    aux_N[, 4]
  
  
  xybar_c <-
    rowMeans(
      xyc_center
    ) +
    (
      2 *
        delta^2 /
        (
          n *
            ep_split
        )
    ) *
    aux_N[, 5]
  
  
  center_cloud <- cbind(
    xbar_c,
    ybar_c,
    x2bar_c,
    y2bar_c,
    xybar_c
  )
  
  
  if (
    any(!is.finite(center_cloud))
  ) {
    
    direction <- rep(
      NA_real_,
      5
    )
    
    assign(
      key,
      direction,
      envir = cache
    )
    
    return(direction)
  }
  
  
  center_mean <-
    colMeans(
      center_cloud
    )
  
  
  ## ==========================================================================
  ## FAST EVALUATION
  ##
  ## beta1, beta0, sa do not change x
  ## ==========================================================================
  
  eval_fast <- function(theta_pert) {
    
    beta1p <- theta_pert[1]
    beta0p <- theta_pert[2]
    sap    <- theta_pert[5]
    
    
    y <-
      beta0p +
      beta1p *
      x_center +
      aux_uy *
      sap
    
    
    yc <- clamp_val(
      y,
      -delta,
      delta
    )
    
    
    xyc <- clamp_val(
      x_center *
        y,
      -delta^2,
      delta^2
    )
    
    
    ybar <-
      rowMeans(yc) +
      (
        2 *
          delta /
          (
            n *
              ep_split
          )
      ) *
      aux_N[, 2]
    
    
    y2bar <-
      rowMeans(
        yc^2
      ) +
      (
        delta^2 /
          (
            n *
              ep_split
          )
      ) *
      aux_N[, 4]
    
    
    xybar <-
      rowMeans(
        xyc
      ) +
      (
        2 *
          delta^2 /
          (
            n *
              ep_split
          )
      ) *
      aux_N[, 5]
    
    
    colMeans(
      cbind(
        xbar_c,
        ybar,
        x2bar_c,
        y2bar,
        xybar
      )
    )
  }
  
  
  ## ==========================================================================
  ## FINITE DIFFERENCE -- FAST PARAMETERS
  ## ==========================================================================
  
  grad_wrt_fast <- function(
    idx,
    lower_bound_check = NULL
  ) {
    
    tp <- theta
    tm <- theta
    
    
    tp[idx] <-
      theta[idx] + h
    
    
    tm[idx] <-
      theta[idx] - h
    
    
    if (
      !is.null(lower_bound_check) &&
      (theta[idx] - h) <= lower_bound_check
    ) {
      
      up <- eval_fast(
        tp
      )
      
      return(
        (
          up -
            center_mean
        ) /
          h
      )
    }
    
    
    up <- eval_fast(
      tp
    )
    
    dn <- eval_fast(
      tm
    )
    
    
    (
      up -
        dn
    ) /
      (
        2 *
          h
      )
  }
  
  
  ## ==========================================================================
  ## FINITE DIFFERENCE -- FULL PARAMETERS
  ##
  ## mu and tau change x
  ## ==========================================================================
  
  grad_wrt_full <- function(
    idx,
    lower_bound_check = NULL
  ) {
    
    tp <- theta
    tm <- theta
    
    
    tp[idx] <-
      theta[idx] + h
    
    
    tm[idx] <-
      theta[idx] - h
    
    
    if (
      !is.null(lower_bound_check) &&
      (theta[idx] - h) <= lower_bound_check
    ) {
      
      up <-
        colMeans(
          sdp_vec_lr(
            aux_ux,
            aux_uy,
            aux_N,
            delta,
            tp,
            ep,
            n
          )
        )
      
      
      return(
        (
          up -
            center_mean
        ) /
          h
      )
    }
    
    
    up <-
      colMeans(
        sdp_vec_lr(
          aux_ux,
          aux_uy,
          aux_N,
          delta,
          tp,
          ep,
          n
        )
      )
    
    
    dn <-
      colMeans(
        sdp_vec_lr(
          aux_ux,
          aux_uy,
          aux_N,
          delta,
          tm,
          ep,
          n
        )
      )
    
    
    (
      up -
        dn
    ) /
      (
        2 *
          h
      )
  }
  
  
  ## ==========================================================================
  ## JACOBIAN
  ## ==========================================================================
  
  d_beta1 <-
    grad_wrt_fast(
      1
    )
  
  
  D_nuisance <- cbind(
    
    ## beta0
    grad_wrt_fast(
      2
    ),
    
    ## mu
    grad_wrt_full(
      3
    ),
    
    ## tau
    grad_wrt_full(
      4,
      0.001
    ),
    
    ## sa
    grad_wrt_fast(
      5,
      0.001
    )
  )
  
  
  if (
    any(!is.finite(d_beta1)) ||
    any(!is.finite(D_nuisance))
  ) {
    
    direction <- rep(
      NA_real_,
      5
    )
    
    assign(
      key,
      direction,
      envir = cache
    )
    
    return(direction)
  }
  
  
  ## ==========================================================================
  ## AUXILIARY COVARIANCE
  ## ==========================================================================
  
  aux_cov <- cov(
    center_cloud
  )
  
  
  aux_cov <-
    0.5 *
    (
      aux_cov +
        t(aux_cov)
    ) +
    1e-8 *
    diag(5)
  
  
  Sigma_inv <-
    tryCatch(
      
      safe_inv_general(
        aux_cov,
        1e-8
      ),
      
      error = function(e)
        NULL
    )
  
  
  if (
    is.null(Sigma_inv)
  ) {
    
    direction <- rep(
      NA_real_,
      5
    )
    
    assign(
      key,
      direction,
      envir = cache
    )
    
    return(direction)
  }
  
  
  ## ==========================================================================
  ## GLS NUISANCE PARTIALLING OUT
  ## ==========================================================================
  
  DtSD <-
    t(D_nuisance) %*%
    Sigma_inv %*%
    D_nuisance
  
  
  DtSd <-
    t(D_nuisance) %*%
    Sigma_inv %*%
    d_beta1
  
  
  DtSD_inv <-
    tryCatch(
      
      safe_inv_general(
        DtSD,
        1e-10
      ),
      
      error = function(e)
        NULL
    )
  
  
  if (
    is.null(DtSD_inv)
  ) {
    
    direction <- rep(
      NA_real_,
      5
    )
    
    assign(
      key,
      direction,
      envir = cache
    )
    
    return(direction)
  }
  
  
  coef <-
    DtSD_inv %*%
    DtSd
  
  
  target <-
    d_beta1 -
    D_nuisance %*%
    coef
  
  
  direction <-
    as.numeric(
      Sigma_inv %*%
        target
    )
  
  
  if (
    any(!is.finite(direction)) ||
    sum(direction^2) <
    1e-20
  ) {
    
    direction <-
      rep(
        NA_real_,
        5
      )
  }
  
  
  assign(
    key,
    direction,
    envir = cache
  )
  
  
  direction
}


## ============================================================================
## 7. EFFICIENT DEPTH
##
## IMPORTANT CORRECTION:
##
## A genuinely undefined numerical Efficient direction is NOT transformed
## into an artificial rejection of the observed point.
##
## Instead:
##     return NA depths
##
## This propagates upward as "unresolved".
## ============================================================================

efficient_depth_lr <- function(
    synth,
    theta,
    aux_ux,
    aux_uy,
    aux_N,
    delta,
    ep,
    n,
    cache
) {
  
  direction <-
    efficient_direction_lr(
      theta,
      aux_ux,
      aux_uy,
      aux_N,
      delta,
      ep,
      n,
      cache
    )
  
  
  if (
    any(!is.finite(direction))
  ) {
    
    return(
      rep(
        NA_real_,
        nrow(synth)
      )
    )
  }
  
  
  center <-
    colMeans(
      synth
    )
  
  
  centered <-
    sweep(
      synth,
      2,
      center,
      "-"
    )
  
  
  covariance <-
    crossprod(
      centered
    ) /
    nrow(synth)
  
  
  covariance <-
    0.5 *
    (
      covariance +
        t(covariance)
    ) +
    1e-10 *
    diag(5)
  
  
  cov_inv <-
    tryCatch(
      
      safe_inv_general(
        covariance,
        1e-10
      ),
      
      error = function(e)
        NULL
    )
  
  
  if (
    is.null(cov_inv)
  ) {
    
    return(
      rep(
        NA_real_,
        nrow(synth)
      )
    )
  }
  
  
  eff_scale <-
    as.numeric(
      t(direction) %*%
        covariance %*%
        direction
    )
  
  
  if (
    !is.finite(eff_scale) ||
    eff_scale <= 1e-14
  ) {
    
    return(
      rep(
        NA_real_,
        nrow(synth)
      )
    )
  }
  
  
  lambda_current <-
    1 /
    log(n)
  
  
  projection <-
    as.numeric(
      centered %*%
        direction
    )
  
  
  Q_eff <-
    projection^2 /
    eff_scale
  
  
  Q_full <-
    rowSums(
      (
        centered %*%
          cov_inv
      ) *
        centered
    )
  
  
  pen <-
    Q_eff +
    lambda_current *
    Q_full
  
  
  depth <-
    1 /
    (
      1 +
        pen
    )
  
  
  ## If anything breaks numerically,
  ## mark this candidate unresolved.
  
  if (
    any(!is.finite(depth))
  ) {
    
    return(
      rep(
        NA_real_,
        nrow(synth)
      )
    )
  }
  
  
  depth
}


## ============================================================================
## 8. SCORE
## ============================================================================

score_Eff_theta <- function(
    theta,
    ux,
    uy,
    noise,
    delta,
    s_dp,
    ep,
    n,
    aux_ux,
    aux_uy,
    aux_N,
    cache
) {
  
  synth <-
    tryCatch(
      
      sdp_vec_lr(
        ux,
        uy,
        noise,
        delta,
        theta,
        ep,
        n
      ),
      
      error = function(e)
        NULL
    )
  
  
  if (
    is.null(synth) ||
    any(!is.finite(synth))
  ) {
    
    return(
      NA_real_
    )
  }
  
  
  synth_full <-
    rbind(
      synth,
      s_dp
    )
  
  
  D_synth <-
    efficient_depth_lr(
      synth_full,
      theta,
      aux_ux,
      aux_uy,
      aux_N,
      delta,
      ep,
      n,
      cache
    )
  
  
  if (
    any(!is.finite(D_synth))
  ) {
    
    return(
      NA_real_
    )
  }
  
  
  obs_idx <-
    R_synthetic +
    1L
  
  
  r <-
    rank(
      D_synth,
      ties.method = "max"
    )[obs_idx]
  
  
  depth_obs <-
    D_synth[
      obs_idx
    ]
  
  
  if (
    !is.finite(r) ||
    !is.finite(depth_obs)
  ) {
    
    return(
      NA_real_
    )
  }
  
  
  ## Negative because optim() minimizes.
  
  -(
    r +
      depth_obs
  )
}


score_Eff_nuisance <- function(
    nuisance,
    beta1,
    ux,
    uy,
    noise,
    delta,
    s_dp,
    ep,
    n,
    aux_ux,
    aux_uy,
    aux_N,
    cache
) {
  
  theta <-
    c(
      beta1,
      nuisance
    )
  
  
  score <-
    score_Eff_theta(
      theta,
      ux,
      uy,
      noise,
      delta,
      s_dp,
      ep,
      n,
      aux_ux,
      aux_uy,
      aux_N,
      cache
    )
  
  
  ## optim() cannot work with NA.
  ##
  ## A huge objective value tells this individual
  ## optimizer trajectory not to use this candidate.
  ##
  ## IMPORTANT:
  ## The outer accept_Efficient() separately tracks whether
  ## optimization actually resolved.
  
  if (
    !is.finite(score)
  ) {
    
    return(
      1e12
    )
  }
  
  
  score
}


## ============================================================================
## 9. DATA-BASED NUISANCE START
##
## Approximate moment-based start from the privatized summary.
##
## s_dp =
##   (xbar, ybar, x2bar, y2bar, xybar)
##
## This is ONLY an optimizer initialization.
## It is not part of the statistical test.
## ============================================================================

make_data_anchor <- function(
    beta1,
    s_dp
) {
  
  xbar  <- s_dp[1]
  ybar  <- s_dp[2]
  x2bar <- s_dp[3]
  y2bar <- s_dp[4]
  
  
  mu_hat <-
    xbar
  
  
  var_x_hat <-
    x2bar -
    xbar^2
  
  
  if (
    !is.finite(var_x_hat)
  ) {
    
    var_x_hat <- 1
  }
  
  
  tau_hat <-
    sqrt(
      max(
        var_x_hat,
        0.001^2
      )
    )
  
  
  beta0_hat <-
    ybar -
    beta1 *
    mu_hat
  
  
  ## Approximate residual variance
  ##
  ## Var(Y) ~= beta1^2 Var(X) + sa^2
  
  var_y_hat <-
    y2bar -
    ybar^2
  
  
  if (
    !is.finite(var_y_hat)
  ) {
    
    var_y_hat <- sa_eps^2
  }
  
  
  sa2_hat <-
    var_y_hat -
    beta1^2 *
    tau_hat^2
  
  
  sa_hat <-
    sqrt(
      max(
        sa2_hat,
        0.001^2
      )
    )
  
  
  anchor <- c(
    beta0_hat,
    mu_hat,
    tau_hat,
    sa_hat
  )
  
  
  clamp_nuisance(
    anchor
  )
}


## ============================================================================
## 10. MULTI-START ACCEPTANCE SEARCH
##
## Logic:
##
##   * Direct evaluations first.
##
##   * Then multiple nuisance optimization starts.
##
##   * If ANY candidate accepts H0:
##          return TRUE
##
##   * If all computations resolve and none accepts:
##          return FALSE
##
##   * If no candidate accepts but at least one essential numerical search
##     fails:
##          return NA
##
## Thus numerical failure cannot manufacture rejection.
## ============================================================================

accept_Efficient <- function(
    beta1,
    nuisance_start_,
    ux,
    uy,
    noise,
    delta,
    s_dp,
    ep,
    n,
    aux_ux,
    aux_uy,
    aux_N,
    cache
) {
  
  ## ==========================================================================
  ## BUILD MULTIPLE STARTS
  ## ==========================================================================
  
  anchor_start <-
    make_data_anchor(
      beta1,
      s_dp
    )
  
  
  neutral_start <- c(
    0.0,   # beta0
    0.0,   # mu
    1.0,   # tau
    0.5    # sa
  )
  
  
  starts <-
    rbind(
      clamp_nuisance(
        nuisance_start_
      ),
      anchor_start,
      clamp_nuisance(
        neutral_start
      )
    )
  
  
  ## Remove duplicated starts
  
  starts <-
    unique(
      round(
        starts,
        digits = 10
      )
    )
  
  
  if (
    is.null(
      dim(starts)
    )
  ) {
    
    starts <-
      matrix(
        starts,
        nrow = 1
      )
  }
  
  
  any_resolved <-
    FALSE
  
  
  any_failure <-
    FALSE
  
  
  ## ==========================================================================
  ## DIRECT EVALUATION AT EACH START
  ## ==========================================================================
  
  for (
    k in seq_len(
      nrow(starts)
    )
  ) {
    
    nuisance_k <-
      starts[
        k,
        ,
        drop = TRUE
      ]
    
    
    theta_k <-
      c(
        beta1,
        nuisance_k
      )
    
    
    direct <-
      -score_Eff_theta(
        theta_k,
        ux,
        uy,
        noise,
        delta,
        s_dp,
        ep,
        n,
        aux_ux,
        aux_uy,
        aux_N,
        cache
      )
    
    
    if (
      is.finite(direct)
    ) {
      
      any_resolved <-
        TRUE
      
      
      if (
        direct >=
        rank_threshold
      ) {
        
        return(TRUE)
      }
      
    } else {
      
      any_failure <-
        TRUE
    }
  }
  
  
  ## ==========================================================================
  ## MULTI-START NUMERICAL PROFILING
  ##
  ## We keep box constraints and L-BFGS-B, but use multiple starts.
  ## ==========================================================================
  
  for (
    k in seq_len(
      nrow(starts)
    )
  ) {
    
    start_k <-
      starts[
        k,
        ,
        drop = TRUE
      ]
    
    
    res <-
      tryCatch(
        
        optim(
          par = start_k,
          fn = score_Eff_nuisance,
          method = "L-BFGS-B",
          
          lower =
            nuisance_lower,
          
          upper =
            nuisance_upper,
          
          control = list(
            maxit = 100
          ),
          
          beta1 = beta1,
          
          ux = ux,
          uy = uy,
          noise = noise,
          
          delta = delta,
          s_dp = s_dp,
          ep = ep,
          n = n,
          
          aux_ux = aux_ux,
          aux_uy = aux_uy,
          aux_N = aux_N,
          
          cache = cache
        ),
        
        error = function(e)
          NULL
      )
    
    
    if (
      is.null(res) ||
      !is.finite(res$value)
    ) {
      
      any_failure <-
        TRUE
      
      next
    }
    
    
    ## Do NOT trust the 1e12 numerical penalty as a genuine
    ## statistical result.
    
    if (
      res$value >=
      1e11
    ) {
      
      any_failure <-
        TRUE
      
      next
    }
    
    
    ## Re-evaluate score at optimizer's reported solution
    ## using the actual statistic.
    
    theta_hat <-
      c(
        beta1,
        res$par
      )
    
    
    final_score <-
      -score_Eff_theta(
        theta_hat,
        ux,
        uy,
        noise,
        delta,
        s_dp,
        ep,
        n,
        aux_ux,
        aux_uy,
        aux_N,
        cache
      )
    
    
    if (
      !is.finite(final_score)
    ) {
      
      any_failure <-
        TRUE
      
      next
    }
    
    
    any_resolved <-
      TRUE
    
    
    if (
      final_score >=
      rank_threshold
    ) {
      
      return(TRUE)
    }
  }
  
  
  ## ==========================================================================
  ## FINAL DECISION
  ## ==========================================================================
  
  ## If there was some unresolved computation and no acceptance was found,
  ## we cannot safely call this a rejection.
  
  if (
    any_failure
  ) {
    
    return(
      NA
    )
  }
  
  
  ## Everything resolved and no nuisance value accepted.
  
  if (
    any_resolved
  ) {
    
    return(
      FALSE
    )
  }
  
  
  ## Nothing resolved at all.
  
  NA
}


## ============================================================================
## 11. ONE POWER SWEEP
##
## Returns:
##
##   power_conservative:
##       unresolved replication -> non-rejection
##
##   power_resolved:
##       rejection proportion only among resolved replications
##
##   failure_rate
##
## The conservative power is the main reported power.
## ============================================================================

run_power_sweep <- function(
    n_obs,
    beta1_true,
    delta,
    ep
) {
  
  theta_truth <- c(
    beta1_true,
    beta0,
    mu_x,
    tau_x,
    sa_eps
  )
  
  
  out <-
    foreach(
      rep_idx = seq_len(reps),
      .combine = rbind,
      .export = setdiff(
        ls(
          envir = .GlobalEnv
        ),
        c(
          "cl",
          "n_obs",
          "beta1_true",
          "delta",
          "ep"
        )
      )
    ) %dopar% {
      
      
      ## ======================================================================
      ## REPRODUCIBLE SEED
      ## ======================================================================
      
      set.seed(
        rep_idx +
          1000L
      )
      
      
      ## ======================================================================
      ## OBSERVED PRIVATE DATASET
      ## ======================================================================
      
      ux1 <-
        matrix(
          rnorm(n_obs),
          nrow = 1,
          ncol = n_obs
        )
      
      
      uy1 <-
        matrix(
          rnorm(n_obs),
          nrow = 1,
          ncol = n_obs
        )
      
      
      N1 <-
        matrix(
          rnorm(5),
          nrow = 1,
          ncol = 5
        )
      
      
      s_dp <-
        sdp_vec_lr(
          ux1,
          uy1,
          N1,
          delta,
          theta_truth,
          ep,
          n_obs
        )[1, ]
      
      
      ## ======================================================================
      ## PRIMARY R=200 INFERENCE CLOUD
      ## ======================================================================
      
      ux_repro <-
        matrix(
          rnorm(
            R_synthetic *
              n_obs
          ),
          nrow =
            R_synthetic,
          ncol =
            n_obs
        )
      
      
      uy_repro <-
        matrix(
          rnorm(
            R_synthetic *
              n_obs
          ),
          nrow =
            R_synthetic,
          ncol =
            n_obs
        )
      
      
      N_repro <-
        matrix(
          rnorm(
            R_synthetic *
              5
          ),
          nrow =
            R_synthetic,
          ncol =
            5
        )
      
      
      ## ======================================================================
      ## INDEPENDENT AUXILIARY CLOUD
      ## ======================================================================
      
      aux_ux <-
        matrix(
          rnorm(
            R_aux *
              n_obs
          ),
          nrow =
            R_aux,
          ncol =
            n_obs
        )
      
      
      aux_uy <-
        matrix(
          rnorm(
            R_aux *
              n_obs
          ),
          nrow =
            R_aux,
          ncol =
            n_obs
        )
      
      
      aux_N <-
        matrix(
          rnorm(
            R_aux *
              5
          ),
          nrow =
            R_aux,
          ncol =
            5
        )
      
      
      eff_cache <-
        new.env(
          parent =
            emptyenv()
        )
      
      
      ## ======================================================================
      ## TEST H0 : beta1 = 0
      ## ======================================================================
      
      accepted <-
        accept_Efficient(
          beta1 = 0.0,
          
          nuisance_start_ =
            nuisance_start,
          
          ux =
            ux_repro,
          
          uy =
            uy_repro,
          
          noise =
            N_repro,
          
          delta =
            delta,
          
          s_dp =
            s_dp,
          
          ep =
            ep,
          
          n =
            n_obs,
          
          aux_ux =
            aux_ux,
          
          aux_uy =
            aux_uy,
          
          aux_N =
            aux_N,
          
          cache =
            eff_cache
        )
      
      
      ## ======================================================================
      ## DECISION / FAILURE ACCOUNTING
      ##
      ## TRUE  = accept H0 -> rejection = 0
      ## FALSE = reject H0 -> rejection = 1
      ## NA    = unresolved -> conservative rejection = 0
      ## ======================================================================
      
      if (
        isTRUE(
          accepted
        )
      ) {
        
        c(
          rejected_conservative = 0,
          rejected_resolved = 0,
          failed = 0
        )
        
      } else if (
        identical(
          accepted,
          FALSE
        )
      ) {
        
        c(
          rejected_conservative = 1,
          rejected_resolved = 1,
          failed = 0
        )
        
      } else {
        
        ## Numerical failure:
        ## never manufacture evidence against H0.
        
        c(
          rejected_conservative = 0,
          rejected_resolved = NA_real_,
          failed = 1
        )
      }
    }
  
  
  ## ==========================================================================
  ## SUMMARY
  ## ==========================================================================
  
  power_conservative <-
    mean(
      out[
        ,
        "rejected_conservative"
      ]
    )
  
  
  resolved_idx <-
    is.finite(
      out[
        ,
        "rejected_resolved"
      ]
    )
  
  
  power_resolved <-
    if (
      any(resolved_idx)
    ) {
      
      mean(
        out[
          resolved_idx,
          "rejected_resolved"
        ]
      )
      
    } else {
      
      NA_real_
    }
  
  
  failure_rate <-
    mean(
      out[
        ,
        "failed"
      ]
    )
  
  
  n_failed <-
    sum(
      out[
        ,
        "failed"
      ]
    )
  
  
  n_resolved <-
    reps -
    n_failed
  
  
  list(
    
    power_conservative =
      power_conservative,
    
    power_resolved =
      power_resolved,
    
    failure_rate =
      failure_rate,
    
    n_failed =
      n_failed,
    
    n_resolved =
      n_resolved
  )
}


## ============================================================================
## 12. POWER GRID
## ============================================================================

n_list <- c(
  100,
  200,
  300,
  400,
  500,
  1000
)


beta1_list <- c(
  0,
  0.2,
  0.4,
  0.6,
  0.8,
  1
)


ep_list <- c(
  1
)


## ============================================================================
## 13. RUN
## ============================================================================

for (
  ep in ep_list
) {
  
  power_table <-
    matrix(
      NA_real_,
      nrow =
        length(n_list),
      ncol =
        length(beta1_list),
      
      dimnames = list(
        n_list,
        beta1_list
      )
    )
  
  
  power_resolved_table <-
    power_table
  
  
  failure_table <-
    power_table
  
  
  failed_count_table <-
    power_table
  
  
  for (
    j in seq_along(
      beta1_list
    )
  ) {
    
    beta1_true <-
      beta1_list[j]
    
    
    for (
      i in seq_along(
        n_list
      )
    ) {
      
      n_obs <-
        n_list[i]
      
      
      t0 <-
        Sys.time()
      
      
      ans <-
        run_power_sweep(
          n_obs =
            n_obs,
          
          beta1_true =
            beta1_true,
          
          delta =
            delta,
          
          ep =
            ep
        )
      
      
      power_table[
        i,
        j
      ] <-
        ans$power_conservative
      
      
      power_resolved_table[
        i,
        j
      ] <-
        ans$power_resolved
      
      
      failure_table[
        i,
        j
      ] <-
        ans$failure_rate
      
      
      failed_count_table[
        i,
        j
      ] <-
        ans$n_failed
      
      
      elapsed <-
        as.numeric(
          Sys.time() -
            t0,
          units =
            "secs"
        )
      
      
      cat(
        sprintf(
          paste0(
            "[Efficient corrected] ",
            "ep=%s beta1=%s n=%d | ",
            "power=%.3f | ",
            "resolved-power=%.3f | ",
            "failure=%.3f (%d/%d) | ",
            "%.1fs\n"
          ),
          
          ep,
          beta1_true,
          n_obs,
          
          ans$power_conservative,
          
          ans$power_resolved,
          
          ans$failure_rate,
          
          ans$n_failed,
          
          reps,
          
          elapsed
        )
      )
      
      
      ## ======================================================================
      ## SAVE AFTER EVERY CELL
      ## ======================================================================
      
      write.csv(
        t(
          power_table
        ),
        
        file.path(
          RESULTS_DIR,
          "Efficient_INT.csv"
        )
      )
      
      
      write.csv(
        t(
          power_resolved_table
        ),
        
        file.path(
          RESULTS_DIR,
          "Efficient_INT_resolved_only.csv"
        )
      )
      
      
      write.csv(
        t(
          failure_table
        ),
        
        file.path(
          RESULTS_DIR,
          "Efficient_failure_rate.csv"
        )
      )
      
      
      write.csv(
        t(
          failed_count_table
        ),
        
        file.path(
          RESULTS_DIR,
          "Efficient_failure_count.csv"
        )
      )
    }
  }
  
  
  ## ==========================================================================
  ## PRINT FINAL TABLES
  ## ==========================================================================
  
  cat(
    "\n============================================================\n"
  )
  
  cat(
    "CONSERVATIVE POWER / REJECTION TABLE\n"
  )
  
  cat(
    "NA numerical failures are counted as NON-REJECTION.\n"
  )
  
  cat(
    "============================================================\n"
  )
  
  
  print(
    t(
      power_table
    )
  )
  
  
  cat(
    "\n============================================================\n"
  )
  
  cat(
    "POWER AMONG RESOLVED REPLICATIONS ONLY\n"
  )
  
  cat(
    "============================================================\n"
  )
  
  
  print(
    t(
      power_resolved_table
    )
  )
  
  
  cat(
    "\n============================================================\n"
  )
  
  cat(
    "NUMERICAL FAILURE RATE\n"
  )
  
  cat(
    "============================================================\n"
  )
  
  
  print(
    t(
      failure_table
    )
  )
  
  
  cat(
    "\nSaved in:\n",
    RESULTS_DIR,
    "\n\n"
  )
}


## ============================================================================
## 14. CLEAN UP
## ============================================================================

try(
  stopCluster(
    cl
  ),
  silent = TRUE
)


cat(
  "\nDone.\n"
)